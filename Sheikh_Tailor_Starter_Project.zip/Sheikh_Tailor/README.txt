SHEIKH TAILOR — STARTER PROJECT

This is a front-end prototype/PWA starter, NOT a production app.

Includes:
- Responsive Black & Gold Urdu website
- Design gallery placeholders
- Rate list supplied by the shop
- Order form that opens a pre-filled WhatsApp message to 03000853273
- Admin visual demo labelled M. Azam

Important:
- Admin section is NOT password-protected or private. It only demonstrates the layout.
- There is no real database, secure account system, server-side permissions, customer records, measurements, payment processing, push notifications, or automatic WhatsApp sending.
- Do not enter or store real customer measurements or private information in this demo.
- WhatsApp opens a prepared message; the user must review and send it.
- PWA installation requires hosting on an HTTPS website.
- A production version needs secure admin authentication, a backend/database, access rules, backups, and privacy protections.

Preview: extract the ZIP and open index.html in a browser.
For PWA testing/install, host the files on HTTPS.
Shop: Sheikh Tailor Shop, Ring Road, Gajjumatta, Lahore, Pakistan
Phone/WhatsApp: 03000853273
Admin display name: M. Azam
